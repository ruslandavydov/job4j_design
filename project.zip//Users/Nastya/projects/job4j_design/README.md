# job4j_design

[![Build Status](https://travis-ci.org/ruslandavydov/job4j_design.svg?branch=master)](https://travis-ci.org/ruslandavydov/job4j_design)
[![codecov](https://codecov.io/gh/ruslandavydov/job4j_design/branch/master/graph/badge.svg?token=ZL3GWQFWNQ)](https://codecov.io/gh/ruslandavydov/job4j_design)