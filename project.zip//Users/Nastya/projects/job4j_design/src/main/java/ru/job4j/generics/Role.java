package ru.job4j.generics;

public class Role extends Base {
    Role(String id) {
        super(id);
    }
}
