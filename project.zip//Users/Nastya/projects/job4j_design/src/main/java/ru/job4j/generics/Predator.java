package ru.job4j.generics;

public class Predator extends Animal {
}
